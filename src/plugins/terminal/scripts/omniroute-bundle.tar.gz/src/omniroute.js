/**
 * Omniroute MCP Server
 * Universal MCP server for routing LLM services in Acode.
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  ListToolsRequestSchema,
  CallToolRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";

class OmnirouteServer {
  constructor() {
    this.server = new Server(
      {
        name: "omniroute",
        version: "1.0.0",
      },
      {
        capabilities: {
          tools: {},
        },
      },
    );
    this.providers = new Map();
    this.setupHandlers();
  }

  setupHandlers() {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      return {
        tools: [
          {
            name: "omniroute_research",
            description: "Research a question using multiple LLM providers",
            inputSchema: {
              type: "object",
              properties: {
                question: { type: "string" },
                providers: { type: "array", items: { type: "string" } },
              },
              required: ["question"],
            },
          },
          {
            name: "omniroute_chat",
            description: "Chat with an LLM provider",
            inputSchema: {
              type: "object",
              properties: {
                message: { type: "string" },
                provider: { type: "string" },
              },
              required: ["message"],
            },
          },
          {
            name: "omniroute_project",
            description: "Generate a project plan from a question",
            inputSchema: {
              type: "object",
              properties: {
                question: { type: "string" },
              },
              required: ["question"],
            },
          },
          {
            name: "omniroute_build",
            description: "Build a project from a plan",
            inputSchema: {
              type: "object",
              properties: {
                projectPlan: { type: "string" },
              },
              required: ["projectPlan"],
            },
          },
          {
            name: "omniroute_health",
            description: "Check Omniroute server health",
            inputSchema: { type: "object", properties: {} },
          },
          {
            name: "omniroute_skills",
            description: "List available Omniroute skills",
            inputSchema: { type: "object", properties: {} },
          },
          {
            name: "omniroute_history",
            description: "View Omniroute conversation history",
            inputSchema: { type: "object", properties: {} },
          },
        ],
      };
    });

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;
      switch (name) {
        case "omniroute_research":
          return await this.research(args.question, args.providers);
        case "omniroute_chat":
          return await this.chat(args.message, args.provider);
        case "omniroute_project":
          return await this.project(args.question);
        case "omniroute_build":
          return await this.build(args.projectPlan);
        case "omniroute_health":
          return await this.health();
        case "omniroute_skills":
          return await this.skills();
        case "omniroute_history":
          return await this.history();
        default:
          throw new Error(`Unknown tool: ${name}`);
      }
    });
  }

  async research(question, providers) {
    const result = {
      question,
      providers: providers || ["openai", "anthropic"],
      status: "completed",
      result: `Researching: ${question}`,
    };
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }

  async chat(message, provider) {
    const result = {
      message,
      provider: provider || "openai",
      status: "completed",
      response: `Chat response for: ${message}`,
    };
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }

  async project(question) {
    const result = {
      question,
      status: "completed",
      plan: `Project plan for: ${question}`,
    };
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }

  async build(projectPlan) {
    const result = {
      projectPlan,
      status: "completed",
      result: `Built project from plan: ${projectPlan}`,
    };
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }

  async health() {
    const result = {
      status: "healthy",
      providers: Array.from(this.providers.keys()),
      uptime: process.uptime(),
    };
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }

  async skills() {
    const result = {
      skills: ["research", "chat", "project", "build"],
    };
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }

  async history() {
    const result = {
      history: [],
    };
    return { content: [{ type: "text", text: JSON.stringify(result) }] };
  }

  async run() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error("Omniroute MCP Server running");
  }
}

export { OmnirouteServer };
