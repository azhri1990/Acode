#!/usr/bin/env node
/**
 * Omniroute CLI entry point.
 * Starts the Omniroute MCP server via stdio.
 */
import { OmnirouteServer } from "../src/omniroute.js";

const server = new OmnirouteServer();
server.run().catch((error) => {
  console.error("Omniroute MCP server failed to start:", error);
  process.exit(1);
});
