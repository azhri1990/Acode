#!/usr/bin/env node
/**
 * MYRA MCP Server - Model Context Protocol Server
 * Exposes MYRA's capabilities (research, chat, project, build, health, skills) as MCP tools
 * so Acode (or any MCP client) can connect and interact with MYRA programmatically.
 */
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema, } from '@modelcontextprotocol/sdk/types.js';
import { LLMClient } from '../lib/llm.js';
import { ResearchStore } from '../lib/sqlite.js';
import { SearchFleet } from '../lib/search.js';
import { buildResearchGraph } from '../graph/researchGraph.js';
import { skillRegistry } from '../lib/skills.js';
import chalk from 'chalk';
export class MyRAMCPServer {
    server;
    llm;
    store;
    fleet;
    constructor() {
        this.server = new Server({
            name: 'myra',
            version: '1.0.0',
        }, {
            capabilities: {
                tools: {},
            },
        });
        this.llm = new LLMClient();
        this.store = new ResearchStore();
        this.fleet = new SearchFleet();
        this.registerToolHandlers();
    }
    registerToolHandlers() {
        // List available tools
        this.server.setRequestHandler(ListToolsRequestSchema, async () => {
            return {
                tools: [
                    {
                        name: 'myra_research',
                        description: 'Perform deep research on a question with citations and synthesis',
                        inputSchema: {
                            type: 'object',
                            properties: {
                                question: { type: 'string', description: 'The research question or topic' },
                            },
                            required: ['question'],
                        },
                    },
                    {
                        name: 'myra_chat',
                        description: 'Conversational assistant mode - chat with MYRA',
                        inputSchema: {
                            type: 'object',
                            properties: {
                                message: { type: 'string', description: 'The message to send to MYRA' },
                            },
                            required: ['message'],
                        },
                    },
                    {
                        name: 'myra_project',
                        description: 'Generate a project plan with implementation steps',
                        inputSchema: {
                            type: 'object',
                            properties: {
                                question: { type: 'string', description: 'The project question or topic to generate a plan for' },
                            },
                            required: ['question'],
                        },
                    },
                    {
                        name: 'myra_build',
                        description: 'Build a project from a JSON project plan',
                        inputSchema: {
                            type: 'object',
                            properties: {
                                projectPlan: { type: 'string', description: 'JSON string containing the project plan' },
                            },
                            required: ['projectPlan'],
                        },
                    },
                    {
                        name: 'myra_health',
                        description: 'Run MYRA health diagnostics and self-heal checks',
                        inputSchema: {
                            type: 'object',
                            properties: {
                                reset: { type: 'boolean', description: 'Reset learning state before health check' },
                            },
                        },
                    },
                    {
                        name: 'myra_skills',
                        description: 'List available MYRA skills',
                        inputSchema: { type: 'object' },
                    },
                    {
                        name: 'myra_history',
                        description: 'View recent research reports from MYRA store',
                        inputSchema: { type: 'object' },
                    },
                    {
                        name: 'myra_terminal',
                        description: 'Execute a terminal/shell command',
                        inputSchema: {
                            type: 'object',
                            properties: {
                                command: { type: 'string', description: 'The shell command to execute' },
                                cwd: { type: 'string', description: 'Working directory (optional)' },
                            },
                            required: ['command'],
                        },
                    },
                    {
                        name: 'myra_file_write',
                        description: 'Write content to a file',
                        inputSchema: {
                            type: 'object',
                            properties: {
                                filePath: { type: 'string', description: 'File path to write to' },
                                content: { type: 'string', description: 'Content to write' },
                            },
                            required: ['filePath', 'content'],
                        },
                    },
                    {
                        name: 'myra_scaffold',
                        description: 'Scaffold a new project (node, react, python, express)',
                        inputSchema: {
                            type: 'object',
                            properties: {
                                type: { type: 'string', description: 'Project type: node, react, python, express' },
                                name: { type: 'string', description: 'Project name' },
                                targetDir: { type: 'string', description: 'Target directory (optional)' },
                            },
                            required: ['type', 'name'],
                        },
                    },
                    {
                        name: 'myra_system_info',
                        description: 'Get system information (OS, architecture, memory, disk)',
                        inputSchema: { type: 'object' },
                    },
                ],
            };
        });
        // Call tools
        this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
            const { name, arguments: argsRaw } = request.params;
            let args;
            try {
                args = typeof argsRaw === 'string' ? JSON.parse(argsRaw) : argsRaw;
            }
            catch {
                return {
                    content: [
                        {
                            type: 'text',
                            text: 'Invalid JSON arguments',
                        },
                    ],
                    isError: true,
                };
            }
            try {
                switch (name) {
                    case 'myra_research': {
                        const result = await this.research(args?.question || '');
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify({
                                        question: result.question,
                                        synthesis: result.synthesis,
                                        status: 'completed',
                                    }, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_chat': {
                        const response = await this.llm.complete([{ role: 'user', content: args?.message || 'hello' }], { model: 'gpt-4o', provider: 'openai' });
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify({
                                        response,
                                        message: args?.message,
                                        status: 'completed',
                                    }, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_project': {
                        const plan = await this.generateProject(args?.question || '');
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify(plan, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_build': {
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify({
                                        projectPlan: args?.projectPlan,
                                        status: 'queued',
                                        message: 'Build plan received. Run `myra build` from terminal to execute.',
                                    }, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_health': {
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify({
                                        status: 'ok',
                                        service: 'myra',
                                        version: '1.0.0',
                                        timestamp: new Date().toISOString(),
                                        reset: args?.reset || false,
                                    }, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_skills': {
                        const skills = skillRegistry.list();
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify({
                                        skills: skills.map((s) => ({
                                            name: s.name,
                                            version: s.version,
                                            description: s.description,
                                        })),
                                    }, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_history': {
                        const reports = await this.store.getRecentReports(10);
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify({
                                        reports: reports.map((r) => ({
                                            id: r.id,
                                            title: r.title,
                                            confidence: r.confidence,
                                            createdAt: r.createdAt,
                                        })),
                                    }, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_terminal': {
                        const { terminalExecutor } = await import('../lib/terminal.js');
                        const result = await terminalExecutor.execute(args?.command || '', { cwd: args?.cwd });
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify({
                                        stdout: result.stdout,
                                        stderr: result.stderr,
                                        exitCode: result.exitCode,
                                        duration: result.duration,
                                    }, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_file_write': {
                        const { terminalExecutor } = await import('../lib/terminal.js');
                        await terminalExecutor.writeFile(args?.filePath || '', args?.content || '');
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify({ success: true, path: args?.filePath }, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_scaffold': {
                        const { terminalExecutor } = await import('../lib/terminal.js');
                        const result = await terminalExecutor.scaffoldProject(args?.type || 'node', args?.name || 'my-project', args?.targetDir);
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify(result, null, 2),
                                },
                            ],
                        };
                    }
                    case 'myra_system_info': {
                        const { terminalExecutor } = await import('../lib/terminal.js');
                        const info = await terminalExecutor.getSystemInfo();
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: JSON.stringify(info, null, 2),
                                },
                            ],
                        };
                    }
                    default:
                        return {
                            content: [
                                {
                                    type: 'text',
                                    text: `Unknown tool: ${name}`,
                                },
                            ],
                            isError: true,
                        };
                }
            }
            catch (error) {
                return {
                    content: [
                        {
                            type: 'text',
                            text: `MYRA MCP error: ${error.message}`,
                        },
                    ],
                    isError: true,
                };
            }
        });
    }
    async research(question) {
        const graph = buildResearchGraph(this.llm, this.fleet, {
            maxIterations: 2,
        });
        const result = await graph.invoke({ question, context: '' });
        const synthesis = result.synthesis || 'No synthesis generated';
        // Save to research store
        const { v4: uuidv4 } = await import('uuid');
        await this.store.saveReport({
            id: uuidv4(),
            queryId: uuidv4(),
            title: question,
            content: synthesis,
            confidence: 'medium',
            createdAt: new Date().toISOString(),
        });
        return { question, synthesis };
    }
    async generateProject(question) {
        const { v4: uuidv4 } = await import('uuid');
        const raw = await this.llm.complete([
            { role: 'system', content: 'Create an implementation plan as JSON' },
            { role: 'user', content: question },
        ], { model: 'gpt-4o', provider: 'openai' });
        return { question, plan: raw, uuid: uuidv4() };
    }
    async start() {
        console.error(chalk.cyan('[MYRA MCP] Starting server...'));
        const transport = new StdioServerTransport();
        await this.server.connect(transport);
        console.error(chalk.cyan('[MYRA MCP] Server started on stdio'));
    }
    async stop() {
        await this.server.close();
        console.error(chalk.cyan('[MYRA MCP] Server stopped'));
    }
}
