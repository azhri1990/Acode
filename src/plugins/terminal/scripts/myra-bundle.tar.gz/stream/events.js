import chalk from 'chalk';
export function createStreamRenderer() {
    return (event) => {
        switch (event.type) {
            case 'node_start':
                console.log(`[iter ${event.iteration}] ${event.node}...`);
                break;
            case 'node_end':
                console.log(chalk.green(`✓ ${event.node} (${event.iteration})`));
                break;
            case 'source_found':
                console.log(chalk.gray(`  📄 ${event.source.title}`));
                break;
            case 'conflict_detected':
                console.log(chalk.yellow(`  ⚠ Conflict: ${event.conflict.claim}`));
                break;
            case 'report_ready':
                console.log('\n' + chalk.bold.green('✓ Research report complete'));
                break;
            case 'error':
                console.error(chalk.red('Error:'), event.message);
                break;
        }
    };
}
