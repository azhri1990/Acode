export type StreamEvent = {
    type: 'start';
} | {
    type: 'node_start';
    node: string;
    iteration: number;
} | {
    type: 'node_end';
    node: string;
    iteration: number;
} | {
    type: 'source_found';
    source: {
        id: string;
        title: string;
        url: string;
        provider: string;
    };
} | {
    type: 'conflict_detected';
    conflict: {
        claim: string;
        sources: string[];
    };
} | {
    type: 'report_ready';
} | {
    type: 'error';
    message: string;
};
export declare function createStreamRenderer(): (event: StreamEvent) => void;
