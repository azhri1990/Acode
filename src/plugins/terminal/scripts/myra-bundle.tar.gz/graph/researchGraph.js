import { createThinkingOrb } from '../lib/thinkingOrbs.js';
import { buildPlannerPrompt } from '../prompts/planner.js';
import { buildSynthesizerPrompt } from '../prompts/synthesizer.js';
import { selfLearn } from '../lib/selfLearn.js';
import { selfHeal } from '../lib/selfHeal.js';
export function buildResearchGraph(llm, fleet, options = {}) {
    const maxIterations = options.maxIterations ?? 3;
    const confidenceThreshold = options.confidenceThreshold ?? 0.8;
    async function planNode(state) {
        // Self-learn: adapt strategy based on learned patterns
        const adaptiveStrategy = selfLearn.getAdaptiveStrategy(state.question);
        const prompt = buildPlannerPrompt(state.question, state.context, adaptiveStrategy.depth);
        const raw = await llm.complete([{ role: 'system', content: prompt }], { provider: 'openai', model: 'gpt-4o', responseFormat: { type: 'json_object' } });
        // Self-heal: validate and repair JSON parsing
        const parsed = selfHeal.validateAndRepairJSON(raw, {
            required: ['subQuestions', 'strategy'],
        });
        const subQuestions = parsed.subQuestions || [state.question];
        const strategy = parsed.strategy || 'Decompose into focused sub-questions';
        // Record pattern for learning
        const patternStr = `plan:${state.question.split(' ').slice(0, 3).join(' ')}`;
        selfLearn.recordPattern(patternStr, 'planning', subQuestions.length > 0);
        return { subQuestions, iteration: state.iteration + 1, strategy };
    }
    async function searchNode(state) {
        const batches = await Promise.all(state.subQuestions.map(async (q) => {
            const results = await fleet.searchAll(q, 5);
            return {
                query: q,
                results: results.map((r) => ({
                    id: r.id,
                    title: r.title,
                    url: r.url,
                    content: r.content,
                    sourceType: r.sourceType,
                    relevanceScore: r.relevanceScore,
                    credibilityScore: r.credibilityScore,
                })),
            };
        }));
        return { searchResults: batches };
    }
    async function synthesizeNode(state) {
        const allSources = state.searchResults.flatMap((b) => b.results.map((r) => ({
            id: r.id,
            title: r.title,
            content: r.content,
            url: r.url,
        })));
        const prompt = buildSynthesizerPrompt(state.question, allSources, []);
        const raw = await llm.complete([{ role: 'system', content: prompt }], { provider: 'openai', model: 'gpt-4o', responseFormat: { type: 'json_object' } });
        // Self-heal: validate and repair JSON parsing errors
        const parsed = selfHeal.validateAndRepairJSON(raw, {
            required: ['executiveSummary', 'sections'],
        });
        return { synthesis: parsed };
    }
    function shouldContinue(state) {
        if (state.iteration >= maxIterations)
            return 'end';
        if (!state.synthesis)
            return 'plan';
        const confidence = state.synthesis?.confidence?.overall ?? 1;
        const hasConflicts = (state.synthesis?.conflicts?.length ?? 0) > 0;
        if ((hasConflicts || confidence < confidenceThreshold) && state.iteration < maxIterations) {
            return 'plan';
        }
        return 'end';
    }
    return {
        async invoke(initialState, options = {}) {
            // Self-heal: validate and repair research state
            let state = selfHeal.repairResearchState(initialState);
            let currentIteration = 0;
            const orb = createThinkingOrb({
                text: 'Starting research...',
                color: 'blue',
            });
            let startTime = Date.now();
            orb.start('Decomposing question...');
            const iterations = [];
            while (true) {
                if (options.cancellationEvent?.cancelled) {
                    orb.update('🛑 Research cancelled by user');
                    orb.stop();
                    return { ...state, cancelled: true };
                }
                const planResult = await planNode(state);
                state.subQuestions = planResult.subQuestions ?? state.subQuestions;
                state.iteration = ++currentIteration;
                state.strategy = planResult.strategy ?? state.strategy;
                orb.update(`Plan ${state.iteration}: ${state.subQuestions.length} sub-questions`);
                // Parallel search execution (Khoj pattern: parallelizable tools)
                const searchResult = await searchNode(state);
                state.searchResults = searchResult.searchResults ?? state.searchResults;
                orb.update(`Found ${state.searchResults.length} result batches`);
                const synthResult = await synthesizeNode(state);
                state.synthesis = synthResult.synthesis ?? state.synthesis;
                // Record iteration history (Khoj pattern: ResearchIteration tracking)
                const iteration = {
                    query: state.question,
                    context: state.subQuestions,
                    onlineContext: Object.fromEntries(state.searchResults.map((b) => [b.query, b.results.map((r) => ({ title: r.title, url: r.url }))])),
                    summarizedResult: state.synthesis?.executiveSummary,
                    warning: state.synthesis?.conflicts?.length > 0 ? 'Conflicts detected' : undefined,
                };
                iterations.push(iteration);
                if (options.onStatus) {
                    options.onStatus(`Iteration ${state.iteration}: ${state.subQuestions.length} sub-questions, ${state.searchResults.length} batches`);
                }
                if (shouldContinue(state) === 'end')
                    break;
                orb.update(`Iteration ${state.iteration}: refining...`);
                const elapsed = (Date.now() - startTime) / 1000;
                orb.update(`⏱️  ${elapsed.toFixed(1)}s elapsed - Iteration ${state.iteration}`);
            }
            const totalTime = (Date.now() - startTime) / 1000;
            orb.update(`✅ Research complete in ${totalTime.toFixed(1)}s`);
            orb.stop();
            // Self-learn: learn from research outcomes
            const sources = state.searchResults.flatMap(r => r.results.map(s => ({ url: s.url, title: s.title })));
            await selfLearn.learnFromResearch(state.question, state.synthesis, sources);
            // Self-heal: final state validation
            state = selfHeal.repairResearchState(state);
            return { ...state, iterations };
        },
        async *stream(initialState, options = {}) {
            yield { type: 'start', state: initialState };
            const result = await this.invoke(initialState, options);
            yield { type: 'end', state: result };
        },
    };
}
