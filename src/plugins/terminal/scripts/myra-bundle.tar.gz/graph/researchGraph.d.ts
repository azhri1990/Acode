import { LLMClient } from '../lib/llm.js';
import { SearchFleet } from '../lib/search.js';
export type ResearchState = {
    question: string;
    subQuestions: string[];
    searchResults: Array<{
        query: string;
        results: Array<{
            id: string;
            title: string;
            url: string;
            content: string;
            sourceType: string;
            relevanceScore: number;
            credibilityScore: number;
        }>;
    }>;
    synthesis: any | null;
    iteration: number;
    maxIterations: number;
    context: string;
};
export declare function buildResearchGraph(llm: LLMClient, fleet: SearchFleet, options?: {
    maxIterations?: number;
    confidenceThreshold?: number;
}): {
    invoke(initialState: Partial<ResearchState>): Promise<ResearchState>;
    stream(initialState: Partial<ResearchState>): AsyncGenerator<{
        type: string;
        state: Partial<ResearchState>;
    }, void, unknown>;
};
