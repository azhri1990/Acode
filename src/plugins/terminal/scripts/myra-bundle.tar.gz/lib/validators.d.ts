import { z } from 'zod';
export declare const SourceSchema: z.ZodObject<{
    id: z.ZodString;
    url: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    content: z.ZodString;
    publishedAt: z.ZodOptional<z.ZodString>;
    sourceType: z.ZodEnum<["web", "academic", "news", "code", "document"]>;
    relevanceScore: z.ZodNumber;
    credibilityScore: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    id: string;
    content: string;
    title: string;
    sourceType: "web" | "academic" | "news" | "code" | "document";
    relevanceScore: number;
    credibilityScore: number;
    url?: string | undefined;
    publishedAt?: string | undefined;
}, {
    id: string;
    content: string;
    title: string;
    sourceType: "web" | "academic" | "news" | "code" | "document";
    relevanceScore: number;
    credibilityScore: number;
    url?: string | undefined;
    publishedAt?: string | undefined;
}>;
export type Source = z.infer<typeof SourceSchema>;
export declare const CitationSchema: z.ZodObject<{
    sourceId: z.ZodString;
    claim: z.ZodString;
    quote: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    sourceId: string;
    claim: string;
    quote?: string | undefined;
}, {
    sourceId: string;
    claim: string;
    quote?: string | undefined;
}>;
export type Citation = z.infer<typeof CitationSchema>;
export declare const ResearchSectionSchema: z.ZodObject<{
    heading: z.ZodString;
    content: z.ZodString;
    sourceIds: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    content: string;
    heading: string;
    sourceIds: string[];
}, {
    content: string;
    heading: string;
    sourceIds: string[];
}>;
export type ResearchSection = z.infer<typeof ResearchSectionSchema>;
export declare const ConflictSchema: z.ZodObject<{
    claim: z.ZodString;
    sources: z.ZodArray<z.ZodObject<{
        sourceId: z.ZodString;
        stance: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        sourceId: string;
        stance: string;
    }, {
        sourceId: string;
        stance: string;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    claim: string;
    sources: {
        sourceId: string;
        stance: string;
    }[];
}, {
    claim: string;
    sources: {
        sourceId: string;
        stance: string;
    }[];
}>;
export type Conflict = z.infer<typeof ConflictSchema>;
export declare const ConfidenceScoreSchema: z.ZodObject<{
    overall: z.ZodNumber;
    sources: z.ZodNumber;
    recency: z.ZodNumber;
    corroboration: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    sources: number;
    overall: number;
    recency: number;
    corroboration: number;
}, {
    sources: number;
    overall: number;
    recency: number;
    corroboration: number;
}>;
export type ConfidenceScore = z.infer<typeof ConfidenceScoreSchema>;
export declare const ResearchReportSchema: z.ZodObject<{
    id: z.ZodString;
    queryId: z.ZodString;
    title: z.ZodString;
    executiveSummary: z.ZodString;
    sections: z.ZodArray<z.ZodObject<{
        heading: z.ZodString;
        content: z.ZodString;
        sourceIds: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        content: string;
        heading: string;
        sourceIds: string[];
    }, {
        content: string;
        heading: string;
        sourceIds: string[];
    }>, "many">;
    citations: z.ZodArray<z.ZodObject<{
        sourceId: z.ZodString;
        claim: z.ZodString;
        quote: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        sourceId: string;
        claim: string;
        quote?: string | undefined;
    }, {
        sourceId: string;
        claim: string;
        quote?: string | undefined;
    }>, "many">;
    conflicts: z.ZodArray<z.ZodObject<{
        claim: z.ZodString;
        sources: z.ZodArray<z.ZodObject<{
            sourceId: z.ZodString;
            stance: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            sourceId: string;
            stance: string;
        }, {
            sourceId: string;
            stance: string;
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        claim: string;
        sources: {
            sourceId: string;
            stance: string;
        }[];
    }, {
        claim: string;
        sources: {
            sourceId: string;
            stance: string;
        }[];
    }>, "many">;
    confidence: z.ZodObject<{
        overall: z.ZodNumber;
        sources: z.ZodNumber;
        recency: z.ZodNumber;
        corroboration: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        sources: number;
        overall: number;
        recency: number;
        corroboration: number;
    }, {
        sources: number;
        overall: number;
        recency: number;
        corroboration: number;
    }>;
    createdAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    id: string;
    executiveSummary: string;
    sections: {
        content: string;
        heading: string;
        sourceIds: string[];
    }[];
    title: string;
    queryId: string;
    citations: {
        sourceId: string;
        claim: string;
        quote?: string | undefined;
    }[];
    conflicts: {
        claim: string;
        sources: {
            sourceId: string;
            stance: string;
        }[];
    }[];
    confidence: {
        sources: number;
        overall: number;
        recency: number;
        corroboration: number;
    };
    createdAt: string;
}, {
    id: string;
    executiveSummary: string;
    sections: {
        content: string;
        heading: string;
        sourceIds: string[];
    }[];
    title: string;
    queryId: string;
    citations: {
        sourceId: string;
        claim: string;
        quote?: string | undefined;
    }[];
    conflicts: {
        claim: string;
        sources: {
            sourceId: string;
            stance: string;
        }[];
    }[];
    confidence: {
        sources: number;
        overall: number;
        recency: number;
        corroboration: number;
    };
    createdAt: string;
}>;
export type ResearchReport = z.infer<typeof ResearchReportSchema>;
export declare const ResearchQuerySchema: z.ZodObject<{
    id: z.ZodString;
    rawQuestion: z.ZodString;
    subQuestions: z.ZodArray<z.ZodString, "many">;
    context: z.ZodOptional<z.ZodArray<z.ZodAny, "many">>;
    depth: z.ZodDefault<z.ZodNumber>;
    createdAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    id: string;
    subQuestions: string[];
    createdAt: string;
    rawQuestion: string;
    depth: number;
    context?: any[] | undefined;
}, {
    id: string;
    subQuestions: string[];
    createdAt: string;
    rawQuestion: string;
    context?: any[] | undefined;
    depth?: number | undefined;
}>;
export type ResearchQuery = z.infer<typeof ResearchQuerySchema>;
