export interface SearchResult {
    id: string;
    title: string;
    url: string;
    content: string;
    publishedAt?: string;
    sourceType: 'web' | 'academic' | 'news' | 'code' | 'document';
    provider: 'exa' | 'tavily';
    relevanceScore: number;
    credibilityScore: number;
}
export interface SearchProvider {
    name: 'exa' | 'tavily';
    search(query: string, opts?: {
        numResults?: number;
    }): Promise<SearchResult[]>;
}
export declare class ExaProvider implements SearchProvider {
    name: "exa";
    private client;
    constructor(apiKey: string);
    search(query: string, opts?: {
        numResults?: number;
    }): Promise<SearchResult[]>;
}
export declare class TavilyProvider implements SearchProvider {
    name: "tavily";
    private client;
    constructor(apiKey: string);
    search(query: string, opts?: {
        numResults?: number;
    }): Promise<SearchResult[]>;
}
export declare class SearchFleet {
    providers: SearchProvider[];
    add(provider: SearchProvider): void;
    searchAll(query: string, numPerProvider?: number): Promise<SearchResult[]>;
}
