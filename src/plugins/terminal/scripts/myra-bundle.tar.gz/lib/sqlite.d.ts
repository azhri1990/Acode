export declare class ResearchStore {
    private db;
    constructor(dbPath?: string);
    private init;
    saveQuery(query: {
        id: string;
        rawQuestion: string;
        subQuestions: string[];
        depth: number;
        createdAt: string;
    }): void;
    saveReport(report: {
        id: string;
        queryId: string;
        title: string;
        content: string;
        confidence: string;
        createdAt: string;
    }): void;
    getRecentReports(limit?: number): Array<{
        id: string;
        title: string;
        createdAt: string;
        confidence: string;
    }>;
    close(): void;
}
