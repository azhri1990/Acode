export declare class Memory {
    private db;
    constructor(dbPath?: string);
    save(queryId: string, content: string, type?: string): void;
    get(queryId: string, type?: string): any[];
    search(queryId: string, search: string, limit?: number): any[];
    clear(queryId: string): void;
}
