export type LLMProvider = 'openai' | 'anthropic' | 'omniroute' | 'ollama';
export interface LLMMessage {
    role: 'system' | 'user' | 'assistant';
    content: string;
}
export declare class LLMClient {
    private openai;
    private anthropic;
    private omniroute;
    private ollama;
    private defaultProvider;
    constructor(options?: {
        defaultProvider?: LLMProvider;
    });
    complete(messages: LLMMessage[], options?: {
        provider?: LLMProvider;
        model?: string;
        temperature?: number;
        maxTokens?: number;
        responseFormat?: {
            type: 'json_object';
        };
    }): Promise<string>;
    completeWithTools(messages: LLMMessage[], tools: Array<{
        type: 'function';
        function: {
            name: string;
            description: string;
            parameters: any;
        };
    }>, options?: {
        provider?: LLMProvider;
        model?: string;
        temperature?: number;
        maxTokens?: number;
    }): Promise<{
        text: string;
        toolCall?: {
            name: string;
            arguments: Record<string, any>;
        };
    }>;
    completeJSON<T>(messages: LLMMessage[], schema: any, options?: {
        provider?: LLMProvider;
        model?: string;
    }): Promise<T>;
}
