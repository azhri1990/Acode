export interface ToolParameters {
    type: 'object';
    properties: Record<string, {
        type: string;
        description: string;
    }>;
    required?: string[];
}
export interface Tool {
    name: string;
    description?: string;
    parameters?: ToolParameters;
    execute: (...args: any[]) => Promise<any>;
}
export declare class ToolRegistry {
    private tools;
    register(name: string, tool: Tool): void;
    get(name: string): Tool | undefined;
    list(): string[];
    run(name: string, ...args: any[]): Promise<any>;
    buildSchemas(): Array<{
        type: 'function';
        function: {
            name: string;
            description: string;
            parameters: any;
        };
    }>;
}
