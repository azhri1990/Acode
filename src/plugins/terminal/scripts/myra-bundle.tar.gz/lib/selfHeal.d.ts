export interface RetryOptions {
    maxAttempts?: number;
    baseDelayMs?: number;
    maxDelayMs?: number;
    backoffMultiplier?: number;
    retryableErrors?: string[];
    onRetry?: (attempt: number, error: Error) => void;
}
export interface FallbackOptions {
    providers: string[];
    currentProvider: string;
    onFallback?: (from: string, to: string, error: Error) => void;
}
export interface HealthStatus {
    provider: string;
    healthy: boolean;
    lastCheck: number;
    consecutiveFailures: number;
    avgLatencyMs: number;
    totalRequests: number;
    successRate: number;
}
/**
 * Self-Heal Engine - Provides automatic error recovery, retry logic,
 * provider fallback, and health monitoring.
 */
export declare class SelfHeal {
    private healthMap;
    private readonly HEALTH_CHECK_WINDOW;
    constructor();
    /**
     * Execute a function with automatic retry and exponential backoff
     */
    withRetry<T>(fn: () => Promise<T>, options?: RetryOptions): Promise<T>;
    /**
     * Execute with provider fallback chain
     */
    withFallback<T>(attempts: Array<{
        provider: string;
        fn: () => Promise<T>;
    }>, options?: FallbackOptions): Promise<T>;
    /**
     * Validate and auto-repair JSON output
     */
    validateAndRepairJSON<T>(raw: string, schema?: {
        required?: string[];
    }): T;
    /**
     * Attempt to repair common JSON syntax issues
     */
    private repairJSON;
    /**
     * Validate research state integrity
     */
    validateResearchState(state: any): boolean;
    /**
     * Auto-repair research state
     */
    repairResearchState(state: any): any;
    /**
     * Record successful operation for health tracking
     */
    recordSuccess(provider: string, latencyMs: number): void;
    /**
     * Record failed operation for health tracking
     */
    recordFailure(provider: string, error: Error): void;
    /**
     * Check if provider is currently healthy
     */
    isHealthy(provider: string): boolean;
    /**
     * Get next healthy provider in fallback chain
     */
    getNextHealthyProvider(current: string, available: string[]): string | null;
    /**
     * Get health status for all providers
     */
    getHealthReport(): HealthStatus[];
    /**
     * Get health status for specific provider
     */
    getProviderHealth(provider: string): HealthStatus | undefined;
    /**
     * Reset health for a provider (e.g., after manual intervention)
     */
    resetHealth(provider: string): void;
    private sleep;
}
export declare const selfHeal: SelfHeal;
