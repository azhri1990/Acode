import { type Options as OraOptions } from 'ora';
export type Color = 'black' | 'red' | 'green' | 'yellow' | 'blue' | 'magenta' | 'cyan' | 'white' | 'gray';
export interface ThinkingOrbOptions {
    text?: string;
    spinner?: OraOptions['spinner'];
    color?: Color;
}
export interface ThinkingOrb {
    start: (text?: string) => void;
    stop: () => void;
    update: (text: string) => void;
    isSpinning: () => boolean;
}
export declare class ThinkingOrbClass implements ThinkingOrb {
    private spinner;
    constructor(options?: ThinkingOrbOptions);
    start(text?: string): void;
    stop(): void;
    update(text: string): void;
    isSpinning(): boolean;
}
export declare function createThinkingOrb(options?: ThinkingOrbOptions): ThinkingOrbClass;
export declare const ThinkingOrbPresets: {
    research: () => ThinkingOrbClass;
    searching: () => ThinkingOrbClass;
    synthesizing: () => ThinkingOrbClass;
    analyzing: () => ThinkingOrbClass;
    default: () => ThinkingOrbClass;
};
export declare function thinkingResearch(): ThinkingOrbClass;
export declare function thinkingSearch(): ThinkingOrbClass;
export declare function thinkingSynthesize(): ThinkingOrbClass;
export declare function thinkingAnalyze(): ThinkingOrbClass;
export declare function thinkingDefault(): ThinkingOrbClass;
