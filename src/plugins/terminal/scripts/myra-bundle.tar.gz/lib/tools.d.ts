import { Tool } from './toolregistry.js';
import { ToolParameters } from './toolregistry.js';
export interface SearchToolResult {
    queryId: string;
    query: string;
    sources: Array<{
        id: string;
        title: string;
        url: string;
        content: string;
        sourceType: string;
        relevanceScore: number;
        credibilityScore: number;
    }>;
    createdAt: string;
}
export declare class SearchTool implements Tool {
    name: string;
    description: string;
    private fleet;
    private store;
    private memory?;
    constructor();
    execute(query: string, maxResults?: number): Promise<SearchToolResult>;
    get parameters(): ToolParameters;
}
export declare class MemorySaveTool implements Tool {
    name: string;
    description: string;
    private memory?;
    constructor();
    execute(queryId: string, content: string, type?: string): Promise<boolean>;
    get parameters(): ToolParameters;
}
export declare class MemorySearchTool implements Tool {
    name: string;
    description: string;
    private memory?;
    constructor();
    execute(queryId: string, search: string, limit?: number): Promise<unknown[]>;
    get parameters(): ToolParameters;
}
export declare class MemoryListTool implements Tool {
    name: string;
    description: string;
    private memory?;
    constructor();
    execute(queryId?: string, type?: string): Promise<unknown[]>;
    get parameters(): ToolParameters;
}
export declare class ReportReadTool implements Tool {
    name: string;
    description: string;
    private store;
    constructor();
    execute(reportId?: string): Promise<unknown>;
    get parameters(): ToolParameters;
}
export declare class WeatherTool implements Tool {
    name: string;
    description: string;
    execute(location: string): Promise<any>;
    get parameters(): ToolParameters;
}
export declare class TimeTool implements Tool {
    name: string;
    description: string;
    execute(timezone?: string): Promise<any>;
    get parameters(): ToolParameters;
}
export declare class CalculatorTool implements Tool {
    name: string;
    description: string;
    execute(expression: string): Promise<number>;
    get parameters(): ToolParameters;
}
export declare class FileReadTool implements Tool {
    name: string;
    description: string;
    execute(filePath: string): Promise<string>;
    get parameters(): ToolParameters;
}
export declare class FileListTool implements Tool {
    name: string;
    description: string;
    execute(directoryPath?: string): Promise<string[]>;
    get parameters(): ToolParameters;
}
export declare class ToolFactory {
    private registry;
    constructor();
    get(name: string): Tool | undefined;
    list(): string[];
    run(name: string, ...args: unknown[]): Promise<any>;
    registerTool(name: string, tool: Tool): void;
    buildTools(): Array<{
        type: 'function';
        function: {
            name: string;
            description: string;
            parameters: any;
        };
    }>;
}
