export interface LearningPattern {
    pattern: string;
    category: string;
    frequency: number;
    successRate: number;
    avgImprovement: number;
    lastSeen: number;
}
export interface ProviderPerformance {
    provider: string;
    queries: Map<string, {
        queryType: string;
        success: boolean;
        quality: number;
    }>;
    totalRequests: number;
    successfulRequests: number;
    avgConfidence: number;
    learningRate: number;
}
export interface QualityMetrics {
    sourceReliability: Map<string, number>;
    topicReliability: Map<string, number>;
    temporalAccuracy: Map<string, number>;
    overallTrend: number;
}
/**
 * Self-Learn Engine - Improves over time by tracking patterns,
 * optimizing provider usage, and adapting strategies.
 */
export declare class SelfLearn {
    private heal;
    private providerPerformance;
    private qualityMetrics;
    private patterns;
    private readonly LEARNING_RATE;
    private readonly MAX_PATTERNS;
    constructor();
    /**
     * Record a successful research outcome and update learning metrics
     */
    learnFromResearch(query: string, synthesis: any, sources: Array<{
        url: string;
        title: string;
    }>, durationMs: number): Promise<void>;
    /**
     * Update provider performance based on usage
     */
    recordProviderUsage(provider: string, success: boolean, quality: number): void;
    /**
     * Get optimal provider for query type
     */
    getOptimalProvider(queryType: string): string | null;
    /**
     * Track and record learning patterns
     */
    recordPattern(pattern: string, category: string, success: boolean): void;
    /**
     * Get most effective patterns
     */
    getEffectivePatterns(limit?: number): LearningPattern[];
    /**
     * Get adaptive strategy based on learned patterns
     */
    getAdaptiveStrategy(query: string): {
        depth: number;
        maxIterations: number;
        useWebSearch: boolean;
        useAcademicSearch: boolean;
    };
    /**
     * Get quality metrics
     */
    getQualityMetrics(): QualityMetrics;
    /**
     * Extract keywords from query for pattern recognition
     */
    private extractKeywords;
    /**
     * Categorize query type for learning
     */
    private categorizeQuery;
    /**
     * Reset learning state (for testing or manual reset)
     */
    reset(): void;
}
export declare const selfLearn: SelfLearn;
