import { ResearchReport } from '../lib/validators.js';
export declare function formatMarkdown(report: ResearchReport): string;
export declare function formatCliBriefing(report: ResearchReport): string;
