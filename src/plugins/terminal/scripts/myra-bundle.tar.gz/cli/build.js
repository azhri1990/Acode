import { LLMClient } from '../lib/llm.js';
import { ResearchStore } from '../lib/sqlite.js';
import chalk from 'chalk';
import * as fs from 'fs';
import * as path from 'path';
export async function build(projectPlan, projectFile) {
    try {
        let plan;
        if (projectFile) {
            const filePath = path.resolve(projectFile);
            if (!fs.existsSync(filePath)) {
                console.error(chalk.red(`❌ File not found: ${filePath}`));
                process.exit(1);
            }
            projectPlan = fs.readFileSync(filePath, 'utf-8');
        }
        try {
            plan = JSON.parse(projectPlan);
        }
        catch (parseError) {
            console.error(chalk.red('\n❌ Build failed: Invalid JSON project plan'));
            console.error(chalk.gray(`Parse error: ${parseError.message}`));
            console.error(chalk.gray('\nTip: Generate a plan first:'));
            console.error(chalk.gray('  myra project "<question>"'));
            console.error(chalk.gray('\nOr pass JSON via a file:'));
            console.error(chalk.gray('  myra build --file plan.json'));
            process.exit(1);
        }
        const llm = new LLMClient();
        const store = new ResearchStore();
        console.log(chalk.cyan('🔧 Starting MYRA build process...\n'));
        // 1. Generate architecture code
        if (plan.architecture) {
            console.log(chalk.yellow('📐 Generating architecture code...'));
            const archPrompt = `Generate a complete Node.js/Express architecture implementation based on this plan: ${JSON.stringify(plan.architecture, null, 2)}. 
Output as valid JavaScript/TypeScript code with:
- Directory structure
- Server setup
- Route handlers
- Middleware
- Error handling`;
            const archCode = await llm.complete([{ role: 'user', content: archPrompt }], { model: 'gpt-4o', provider: 'openai' });
            console.log(chalk.green('✅ Architecture generated'));
            console.log(archCode.substring(0, 500) + '...\n');
        }
        // 2. Generate database schema code
        if (plan.database_schema) {
            console.log(chalk.yellow('🗄️ Generating database schema code...'));
            const dbPrompt = `Generate Prisma schema and migration code based on this database plan: ${JSON.stringify(plan.database_schema, null, 2)}.
Output Prisma schema file content and migration up() function.`;
            const dbCode = await llm.complete([{ role: 'user', content: dbPrompt }], { model: 'gpt-4o', provider: 'openai' });
            console.log(chalk.green('✅ Database schema generated'));
            console.log(dbCode.substring(0, 500) + '...\n');
        }
        // 3. Generate API routes
        if (plan.api_endpoints) {
            console.log(chalk.yellow('🛠️ Generating API routes code...'));
            const apiPrompt = `Generate Express route handlers for these API endpoints: ${JSON.stringify(plan.api_endpoints, null, 2)}.
Output as TypeScript/Express route files with validation, controllers, and error handling.`;
            const apiCode = await llm.complete([{ role: 'user', content: apiPrompt }], { model: 'gpt-4o', provider: 'openai' });
            console.log(chalk.green('✅ API routes generated'));
            console.log(apiCode.substring(0, 500) + '...\n');
        }
        // 4. Generate testing strategy
        if (plan.testing) {
            console.log(chalk.yellow('🧪 Generating test suite...'));
            const testPrompt = `Generate Jest/Pytest test suite for this testing strategy: ${JSON.stringify(plan.testing, null, 2)}.
Output test files with describe(), it(), expect() blocks.`;
            const testCode = await llm.complete([{ role: 'user', content: testPrompt }], { model: 'gpt-4o', provider: 'openai' });
            console.log(chalk.green('✅ Test suite generated'));
            console.log(testCode.substring(0, 500) + '...\n');
        }
        // 5. Generate deployment config
        if (plan.deployment) {
            console.log(chalk.yellow('🚀 Generating deployment configuration...'));
            const deployPrompt = `Generate Dockerfile and deployment configuration for this plan: ${JSON.stringify(plan.deployment, null, 2)}.
Output Dockerfile, docker-compose.yml, and environment variables.`;
            const deployCode = await llm.complete([{ role: 'user', content: deployPrompt }], { model: 'gpt-4o', provider: 'openai' });
            console.log(chalk.green('✅ Deployment config generated'));
            console.log(deployCode.substring(0, 500) + '...\n');
        }
        // 6. Self-learn from build
        console.log(chalk.cyan('🧠 Self-learning from build process...'));
        await store.close();
        console.log(chalk.green.bold('✅ MYRA Build Complete!'));
        console.log(chalk.gray('📦 All code generation complete. Review and execute manually.'));
    }
    catch (error) {
        console.error(chalk.red(`❌ Build failed: ${error.message}`));
        process.exit(1);
    }
}
