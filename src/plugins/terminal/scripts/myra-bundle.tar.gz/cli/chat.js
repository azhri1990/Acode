import { LLMClient } from '../lib/llm.js';
import { ResearchStore } from '../lib/sqlite.js';
import chalk from 'chalk';
export async function chat(message) {
    if (!message) {
        console.log(chalk.red('❌ Chat requires a message.'));
        console.log('Usage: myra chat "What is AI?"');
        return;
    }
    const store = new ResearchStore();
    const records = store.getRecentReports(10);
    const context = records.map((r) => `[${r.title}]: ${r.content}`).join('\n');
    const systemPrompt = `You are MYRA, a deep research assistant with JARVIS capabilities. You have access to past research results. Answer questions helpfully.`;
    const messages = [
        { role: 'system', content: `${systemPrompt}\n\nRecent research context:\n${context}` },
        { role: 'user', content: message },
    ];
    const llm = new LLMClient();
    try {
        const result = await llm.complete(messages, { model: 'gpt-4o', provider: 'openai' });
        console.log(chalk.green('\n💬 MYRA:\n' + result));
    }
    catch (err) {
        console.error(chalk.red(`Chat failed: ${err.message || err}`));
        console.error(chalk.yellow('Hint: Set OPENAI_API_KEY or ANTHROPIC_API_KEY environment variable.'));
    }
    store.close();
}
