import { runResearch } from '../lib/research.js';
import chalk from 'chalk';
export async function research(question) {
    console.log(chalk.blue('🔍 Initiating deep research on:', question));
    console.log(chalk.cyan(`🔍 Researching: ${question}`));
    const result = await runResearch(question);
    if (result) {
        console.log(chalk.green('✅ Research completed successfully!'));
    }
    else {
        console.log(chalk.yellow('⚠️  No research result generated'));
    }
}
