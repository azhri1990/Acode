import chalk from 'chalk';
import { ResearchStore } from '../lib/sqlite.js';
import { v4 as uuidv4 } from 'uuid';
import { LLMClient } from '../lib/llm.js';
export async function project(question) {
    if (!question) {
        console.log(chalk.red('❌ Project requires a question.'));
        return;
    }
    const store = new ResearchStore();
    const prompts = [
        'Create an implementation plan for: ' + question,
        'The plan should include:',
        '1. Architecture design with component breakdown',
        '2. Database schema design',
        '3. API endpoint specifications',
        '4. Deployment configuration',
        '5. Testing strategy',
        '6. Rollout timeline (2-week and 8-week phases)',
        'Provide as valid JSON with these fields:',
        '{"architecture": {}, "database_schema": [], "api_endpoints": [], "deployment": {}, "testing": [], "timeline": {}}',
    ];
    try {
        const messages = [];
        messages.push({ role: 'system', content: prompts.join('\n') });
        messages.push({ role: 'user', content: question });
        const llm = new LLMClient();
        const raw = await llm.complete(messages, { model: 'gpt-4o', provider: 'openai' });
        const parsed = JSON.parse(raw);
        store.saveReport({
            id: uuidv4(),
            queryId: uuidv4(),
            title: question,
            content: JSON.stringify(parsed, null, 2),
            confidence: 'medium',
            createdAt: new Date().toISOString(),
        });
        console.log(chalk.green('✅ Project plan generated and saved.'));
        console.log(JSON.stringify(parsed, null, 2));
    }
    catch (err) {
        console.error(chalk.red(`Project generation failed: ${err.message}`));
    }
    store.close();
}
