import { selfHeal } from '../lib/selfHeal.js';
import { selfLearn } from '../lib/selfLearn.js';
import chalk from 'chalk';
export async function health(reset) {
    if (reset) {
        selfLearn.reset();
        console.log(chalk.green('✅ Learning state reset.'));
        return;
    }
    console.log(chalk.bold('\n🔬 MYRA Health Diagnostics\n'));
    // Provider health
    const providerHealth = selfHeal.getHealthReport();
    console.log(chalk.cyan('Provider Health:'));
    for (const h of providerHealth) {
        const status = h.healthy ? chalk.green('● HEALTHY') : chalk.red('● UNHEALTHY');
        console.log(`  ${h.provider}: ${status} | Requests: ${h.totalRequests} | Success Rate: ${(h.successRate * 100).toFixed(1)}% | Avg Latency: ${h.avgLatencyMs.toFixed(0)}ms`);
    }
    // Learning patterns
    const patterns = selfLearn.getEffectivePatterns(10);
    console.log(chalk.cyan('\nEffective Patterns:'));
    for (const p of patterns) {
        console.log(`  ${p.pattern} (${p.category}): freq=${p.frequency}, success=${(p.successRate * 100).toFixed(1)}%`);
    }
    // Quality metrics
    const metrics = selfLearn.getQualityMetrics();
    console.log(chalk.cyan('\nQuality Metrics:'));
    console.log(`  Overall Trend: ${(metrics.overallTrend * 100).toFixed(1)}%`);
    console.log(`  Topic Reliability (top 5):`);
    let count = 0;
    for (const [topic, reliability] of metrics.topicReliability) {
        if (count >= 5)
            break;
        console.log(`    ${topic}: ${(reliability * 100).toFixed(1)}%`);
        count++;
    }
    // Provider performance
    console.log(chalk.cyan('\nProvider Performance:'));
    // Note: providerPerformance is private, would need getter
    console.log('  (Metrics tracked internally)');
    console.log(chalk.bold('\n✅ Diagnostics complete.'));
}
