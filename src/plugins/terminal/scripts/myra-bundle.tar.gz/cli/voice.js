import chalk from 'chalk';
export async function voice() {
    console.log(chalk.gray('Please enable microphone access in your terminal.'));
    console.log(chalk.gray('Voice input will be converted to text and processed by MYRA.'));
    console.log(chalk.gray('Type "exit" to stop the voice session.\n'));
}
