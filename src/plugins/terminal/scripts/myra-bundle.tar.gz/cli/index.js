#!/usr/bin/env node
import { Command } from 'commander';
import { research } from './research.js';
import { history } from './history.js';
import { chat } from './chat.js';
import { voice } from './voice.js';
import { project } from './project.js';
import { build } from './build.js';
import { health } from './health.js';
import { MyRAAPI } from '../lib/apiServer.js';
import { skillRegistry } from '../lib/skills.js';
import chalk from 'chalk';
// Initialize commander
const program = new Command();
program
    .name('myra')
    .description('Deep research assistant with JARVIS capabilities')
    .version('1.0.0');
// Main commands
program
    .command('research <question>')
    .description('Research a question and generate a cited report')
    .action((question) => {
    console.log(chalk.cyan('🔍 Starting research...'));
    research(question);
});
program
    .command('history')
    .description('Show recent research reports')
    .action(() => {
    console.log(chalk.cyan('📜 Showing history...'));
    history();
});
program
    .command('health')
    .description('Show self-heal/self-learn diagnostics')
    .option('-r, --reset', 'Reset learning state')
    .action((options) => {
    console.log(chalk.cyan('🔬 Running health diagnostics...'));
    health(options.reset);
});
program
    .command('chat [message]')
    .description('Conversational assistant mode')
    .action((message) => {
    console.log(chalk.cyan('💬 Starting chat...'));
    chat(message);
});
program
    .command('voice')
    .description('Voice interface: speak with MYRA')
    .action(() => {
    console.log(chalk.cyan('🎙️  Activating voice interface...'));
    voice();
});
program
    .command('project <question>')
    .description('Research a question and generate a project plan with implementation steps')
    .action((question) => {
    console.log(chalk.cyan('📋 Generating project plan...'));
    project(question);
});
program
    .command('build [project-plan]')
    .description('Build a project from a JSON project plan')
    .option('-f, --file <path>', 'Read project plan JSON from a file')
    .action((projectPlan, options) => {
    console.log(chalk.cyan('🔧 Building project...'));
    if (options.file) {
        build('', options.file);
    }
    else if (!projectPlan) {
        console.log(chalk.red('❌ Build requires a project plan.'));
        console.log(chalk.gray('\nUsage:'));
        console.log(chalk.gray('  myra build <json-plan>'));
        console.log(chalk.gray('  myra build --file plan.json'));
    }
    else {
        build(projectPlan);
    }
});
program
    .command('api')
    .description('Start MYRA API server')
    .action(async () => {
    console.log(chalk.cyan('🌐 Starting MYRA API server...'));
    await new MyRAAPI(3000).start();
});
program
    .command('skills')
    .description('List available skills')
    .action(() => {
    console.log(chalk.cyan('🔧 Available skills:'));
    const skills = skillRegistry.list();
    skills.forEach(skill => {
        console.log(`  - ${skill.name} (${skill.version}) - ${skill.description}`);
    });
});
program
    .command('mcp-server')
    .description('Start MYRA as an MCP server (for IDE/editor integration like Acode)')
    .action(async () => {
    console.log(chalk.cyan('🔌 Starting MYRA MCP server...'));
    const { MyRAMCPServer } = await import('../mcp/server.js');
    const server = new MyRAMCPServer();
    await server.start();
});
program
    .command('help [command]')
    .description('display help for command')
    .action(() => {
    program.outputHelp();
});
// Parse and execute
program.parse(process.argv);
