import { ResearchStore } from '../lib/sqlite.js';
import chalk from 'chalk';
export async function history() {
    const store = new ResearchStore();
    const records = store.getRecentReports(20);
    if (records.length === 0) {
        console.log(chalk.yellow('📜 No research history found.'));
        store.close();
        return;
    }
    console.log(chalk.bold('\n📜 Research History:\n'));
    for (const record of records) {
        const date = new Date(record.createdAt).toLocaleString();
        console.log(chalk.cyan(`  ${record.id}. ${record.title}`));
        console.log(chalk.gray(`     ${date} | Confidence: ${record.confidence}`));
        console.log('');
    }
    store.close();
}
