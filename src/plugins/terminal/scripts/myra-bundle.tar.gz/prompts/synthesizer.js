export function buildSynthesizerPrompt(question, sources, priorConflicts = []) {
    const sourcesText = sources
        .map((s) => `[${s.id}] ${s.title} (${s.url ?? "no URL"}):\n${s.content.slice(0, 2000)}\n`)
        .join('\n---\n');
    const conflictsText = priorConflicts.length
        ? '\nPRIOR CONFLICTS TO RESOLVE:\n' +
            priorConflicts
                .map((c) => `- ${c.claim}: ${c.sources.map((s) => `${s.sourceId}: ${s.stance}`).join(' | ')}`)
                .join('\n')
        : '';
    return `
You are MYRA, a deep research assistant that synthesizes research findings into comprehensive, cited reports.

RESEARCH QUESTION: ${question}

SOURCES:
${sourcesText}

${conflictsText}

INSTRUCTIONS:
1. Lead with an Executive Summary (bottom line up front, 2-4 sentences).
2. Every factual claim must have an inline citation like [source_id].
3. Organize into logical sections with headings (e.g., Background, Current State of the Art, Key Findings, Technical Deep Dive, Challenges & Open Questions, Future Outlook).
4. If sources contradict, create a "Conflicts" section explaining each disagreement.
5. Score source confidence: credibility, recency, corroboration.
6. Add "Open Questions" section for unresolved items.
7. Keep citations consistent: use the source IDs from the sources list.
8. Score source confidence: credibility, recency, corroboration.
Output ONLY valid JSON matching this schema:
{
  "executiveSummary": string,
  "sections": [{ "heading": string, "content": string, "sourceIds": string[] }],
  "conflicts": [{ "claim": string, "sources": [{ "sourceId": string, "stance": string }] }],
  "confidence": { "overall": number, "sources": number, "recency": number, "corroboration": number }
}

Scores are 0-1. Overall should weight credibility, recency, and corroboration.
`;
}
