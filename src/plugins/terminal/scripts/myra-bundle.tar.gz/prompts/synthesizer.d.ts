export declare function buildSynthesizerPrompt(question: string, sources: Array<{
    id: string;
    title: string;
    content: string;
    url?: string;
}>, priorConflicts?: Array<{
    claim: string;
    sources: Array<{
        sourceId: string;
        stance: string;
    }>;
}>): string;
