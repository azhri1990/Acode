export declare function buildPlannerPrompt(question: string, context?: string, depth?: number): string;
