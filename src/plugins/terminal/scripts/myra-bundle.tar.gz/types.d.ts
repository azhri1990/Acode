export type OmniRouteConfig = {
    baseURL: string;
    apiKey: string;
    providerId?: string;
};
export type OmniRouteModel = {
    id: string;
    name?: string;
    owned_by?: string;
    object?: string;
    contextWindow?: number;
    maxTokens?: number;
    supportsVision?: boolean;
    supportsTools?: boolean;
    supportsStreaming?: boolean;
    supportsTemperature?: boolean;
    supportsReasoning?: boolean;
    supportsAttachment?: boolean;
    pricing?: any;
};
export type OmniRouteModelMetadata = {
    name?: string;
    contextWindow?: number;
    maxTokens?: number;
    supportsVision?: boolean;
    supportsTools?: boolean;
    supportsStreaming?: boolean;
    supportsTemperature?: boolean;
    supportsReasoning?: boolean;
    supportsAttachment?: boolean;
    pricing?: any;
};
export type ResearchQuery = {
    id: string;
    rawQuestion: string;
    subQuestions: string[];
    depth: number;
    createdAt: string;
};
export type ResearchReport = {
    id: string;
    queryId: string;
    title: string;
    content: string;
    confidence: string;
    createdAt: string;
};
export type ReportSection = {
    heading: string;
    content: string;
    sourceIds: string[];
};
export type Conflict = {
    claim: string;
    sources: Array<{
        sourceId: string;
        stance: string;
    }>;
};
export type Confidence = {
    overall: number;
    sources: number;
    recency: number;
    corroboration: number;
};
export type LLMProvider = 'openai' | 'anthropic';
export type LLMMessage = {
    role: 'system' | 'user' | 'assistant';
    content: string;
};
export type ToolCall = {
    id: string;
    name: string;
    arguments: Record<string, any>;
};
